from telegram import (
    Update,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

from telegram.ext import (
    Application,
    CommandHandler,
    CallbackQueryHandler,
    MessageHandler,
    ContextTypes,
    filters
)

import math
import os

TOKEN = os.environ["BOT_TOKEN"]


# ==========================
# HELPER FUNCTIONS
# ==========================

def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(n ** 0.5) + 1):
        if n % i == 0:
            return False
    return True


def factor_list(n):
    n = abs(n)
    if n == 0:
        return "Infinite"
    arr = []
    for i in range(1, n + 1):
        if n % i == 0:
            arr.append(str(i))
    return ", ".join(arr)


# ==========================
# START
# ==========================

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):

    keyboard = [
        [InlineKeyboardButton("🔢 Number Information", callback_data="number")],
        [InlineKeyboardButton("🔤 Alphabet Information", callback_data="alpha")],
        [InlineKeyboardButton("🧮 Calculator", callback_data="calc")]
    ]

    await update.message.reply_text(
        "👋 Hello!\n\n"
        "Welcome to Smart Maths Bot\n\n"
        "Choose any option.",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )


# ==========================
# MENU
# ==========================

async def menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await start(update, context)


# ==========================
# HELP
# ==========================

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):

    await update.message.reply_text(
"""🤖 SMART MATH BOT

Commands

/start - Start Bot
/menu - Show Menu
/help - Help

Modes

🔢 Number Information

Example
66

🔤 Alphabet Information

Example
A

🧮 Calculator

Examples

25+5
100-40
8*9
81/9
5**3
10%3
"""
    )


# ==========================
# BUTTON HANDLER
# ==========================

async def buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):

    query = update.callback_query
    await query.answer()

    if query.data == "number":
        context.user_data["mode"] = "number"
        await query.message.reply_text(
            "Send any integer.\n\n"
            "Example:\n"
            "66"
        )

    elif query.data == "alpha":
        context.user_data["mode"] = "alpha"
        await query.message.reply_text(
            "Send one alphabet.\n\n"
            "Example:\nA"
        )

    elif query.data == "calc":
        context.user_data["mode"] = "calc"
        await query.message.reply_text(
            "Calculator Mode\n\n"
            "Examples:\n"
            "5+8\n"
            "20-4\n"
            "8*6\n"
            "50/2\n"
            "5**3\n"
            "10%3"
        )


# ==========================
# MESSAGE HANDLER
# ==========================

async def messages(update: Update, context: ContextTypes.DEFAULT_TYPE):

    mode = context.user_data.get("mode")
    text = update.message.text.strip()

    # ----------------------
    # NUMBER MODE
    # ----------------------

    if mode == "number":

        if not text.lstrip("-").isdigit():
            await update.message.reply_text("❌ Invalid Number")
            return

        n = int(text)

        if n <= 1:
            p = "Neither Prime nor Composite"
        elif is_prime(n):
            p = "Prime"
        else:
            p = "Composite"

        even = "Even" if n % 2 == 0 else "Odd"
        natural = "Yes" if n >= 1 else "No"
        whole = "Yes" if n >= 0 else "No"
        integer = "Yes"
        square = n ** 2
        cube = n ** 3
        binary = bin(n)
        octal = oct(n)
        hexa = hex(n).upper()

        try:
            sqrt = round(math.sqrt(abs(n)), 4)
        except:
            sqrt = "Not Available"

        try:
            if 0 <= n <= 1000:
                factorial = math.factorial(n)
            else:
                factorial = "Too Large"
        except:
            factorial = "Not Available"

        reply = f"""📊 NUMBER INFORMATION

Number : {n}

Prime/Composite :
{p}

Even/Odd :
{even}

Natural :
{natural}

Whole :
{whole}

Integer :
{integer}

Square :
{square}

Cube :
{cube}

Square Root :
{sqrt}

Factorial :
{factorial}

Binary :
{binary}

Octal :
{octal}

Hexadecimal :
{hexa}

Factors :
{factor_list(n)}
"""
        await update.message.reply_text(reply)

    # ----------------------
    # ALPHABET MODE
    # ----------------------

    elif mode == "alpha":

        if len(text) != 1 or not text.isalpha():
            await update.message.reply_text("❌ Send only one alphabet.")
            return

        letter = text
        kind = "Vowel" if letter.lower() in "aeiou" else "Consonant"
        case = "Uppercase" if letter.isupper() else "Lowercase"
        ascii_value = ord(letter)
        position = ord(letter.lower()) - 96

        await update.message.reply_text(
f"""🔤 ALPHABET INFORMATION

Letter :
{letter}

Type :
{kind}

Case :
{case}

ASCII :
{ascii_value}

Position :
{position}
"""
        )

    # ----------------------
    # CALCULATOR MODE
    # ----------------------

    elif mode == "calc":

        try:
            allowed = "0123456789+-*/().% "

            if not all(ch in allowed for ch in text):
                await update.message.reply_text("❌ Invalid expression.")
                return

            result = eval(text, {"__builtins__": None}, {})

            await update.message.reply_text(
f"""🧮 CALCULATOR

Expression :
{text}

Answer :
{result}
"""
            )

        except Exception:
            await update.message.reply_text("❌ Invalid calculation.")

    # ----------------------
    # NO MODE SELECTED
    # ----------------------

    else:
        await update.message.reply_text(
            "Please use /start to choose an option first."
        )


# ==========================
# MAIN
# ==========================

app = Application.builder().token(TOKEN).build()

app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("menu", menu))
app.add_handler(CommandHandler("help", help_command))
app.add_handler(CallbackQueryHandler(buttons))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, messages))

print("Bot Running...")

app.run_polling()
