# Smart Maths Bot 🤖

A Telegram bot that provides Number Information, Alphabet Information, and a Calculator.

## Setup

### 1. Install dependencies
```
pip install -r requirements.txt
```

### 2. Set your Bot Token
Create a `.env` file or set the environment variable:
```
BOT_TOKEN=your_token_here
```

### 3. Run the bot
```
python smart_maths_bot.py
```

---

## Deploy on Railway (Free 24/7 Hosting)

1. Go to https://railway.app and sign up (free)
2. Click **New Project → Deploy from GitHub**
3. Upload or push this folder to a GitHub repo
4. In Railway project settings, go to **Variables**
5. Add: `BOT_TOKEN = your_token_here`
6. Railway will auto-detect Python and run the bot 24/7 ✅

## Deploy on Render (Free 24/7 Hosting)

1. Go to https://render.com and sign up (free)
2. Click **New → Background Worker**
3. Connect your GitHub repo
4. Set **Build Command**: `pip install -r requirements.txt`
5. Set **Start Command**: `python smart_maths_bot.py`
6. Add environment variable: `BOT_TOKEN = your_token_here`
7. Click Deploy ✅

---

## Commands
- `/start` — Show main menu
- `/menu` — Show main menu
- `/help` — Show help and examples

## Modes
- 🔢 **Number Information** — Prime, Even/Odd, Square, Cube, Factorial, Binary, Hex, Factors, etc.
- 🔤 **Alphabet Information** — Vowel/Consonant, Case, ASCII, Position
- 🧮 **Calculator** — Basic arithmetic (`+`, `-`, `*`, `/`, `**`, `%`)
